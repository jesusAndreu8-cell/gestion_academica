-- Esquema de gestion_academica (idempotente: no borra datos)
CREATE TABLE IF NOT EXISTS profesor (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nif VARCHAR(9) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    apellido1 VARCHAR(100) NOT NULL,
    apellido2 VARCHAR(100),
    departamento VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grupo (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    curso INT NOT NULL,
    tutor_id INT UNSIGNED,
    CONSTRAINT fk_grupo_profesor FOREIGN KEY (tutor_id) REFERENCES profesor(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alumno (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nia VARCHAR(15) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    apellido1 VARCHAR(100) NOT NULL,
    apellido2 VARCHAR(100),
    email VARCHAR(150) NOT NULL UNIQUE,
    grupo_id INT UNSIGNED,
    CONSTRAINT fk_alumno_grupo FOREIGN KEY (grupo_id) REFERENCES grupo(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Relación N:M: tutorías TFG (profesor <-> alumno)
CREATE TABLE IF NOT EXISTS tutoria_tfg (
    profesor_id INT UNSIGNED NOT NULL,
    alumno_id INT UNSIGNED NOT NULL,
    nota DECIMAL(4,2) NULL,
    observaciones VARCHAR(500),
    PRIMARY KEY (profesor_id, alumno_id),
    CONSTRAINT fk_tutoria_profesor FOREIGN KEY (profesor_id) REFERENCES profesor(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_tutoria_alumno FOREIGN KEY (alumno_id) REFERENCES alumno(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;
