package org.iesvdm.gestion.servicios;

import java.util.List;
import java.util.Optional;

import org.iesvdm.gestion.dao.GrupoDAO;
import org.iesvdm.gestion.modelo.Grupo;
import org.springframework.stereotype.Service;

@Service
public class GrupoService {

	private final GrupoDAO grupoDAO;

	public GrupoService(GrupoDAO grupoDAO) {
		this.grupoDAO = grupoDAO;
	}

	public List<Grupo> findAll() {
		return grupoDAO.findAll();
	}

	public Optional<Grupo> findById(int id) {
		return grupoDAO.findById(id);
	}

	public void save(Grupo grupo) {
		grupoDAO.save(grupo);
	}

	public void update(Grupo grupo) {
		grupoDAO.update(grupo);
	}

	public void delete(int id) {
		grupoDAO.delete(id);
	}
}
