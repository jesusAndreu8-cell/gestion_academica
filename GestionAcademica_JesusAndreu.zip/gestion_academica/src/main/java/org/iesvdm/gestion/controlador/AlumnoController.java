package org.iesvdm.gestion.controlador;

import java.util.Map;
import java.util.stream.Collectors;

import org.iesvdm.gestion.modelo.Alumno;
import org.iesvdm.gestion.servicios.AlumnoService;
import org.iesvdm.gestion.servicios.GrupoService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import jakarta.validation.Valid;

@Controller
public class AlumnoController {

	private final AlumnoService alumnoService;
	private final GrupoService grupoService;

	public AlumnoController(AlumnoService alumnoService, GrupoService grupoService) {
		this.alumnoService = alumnoService;
		this.grupoService = grupoService;
	}

	@GetMapping("/alumnos")
	public String listar(Model model) {
		model.addAttribute("alumnos", alumnoService.findAll());
		model.addAttribute("nombresGrupos", nombresGrupos());
		return "alumnos";
	}

	@GetMapping("/alumnos/crear")
	public String crear(Model model) {
		model.addAttribute("alumno", new Alumno());
		model.addAttribute("grupos", grupoService.findAll());
		return "form-alumno";
	}

	@PostMapping("/alumnos/crear")
	public String submitCrear(@Valid @ModelAttribute("alumno") Alumno alumno, BindingResult br, Model model) {
		if (br.hasErrors()) {
			model.addAttribute("grupos", grupoService.findAll());
			return "form-alumno";
		}
		try {
			alumnoService.save(alumno);
		} catch (DataIntegrityViolationException e) {
			br.reject("duplicado", "Ya existe un alumno con ese NIA o email.");
			model.addAttribute("grupos", grupoService.findAll());
			return "form-alumno";
		}
		return "redirect:/alumnos";
	}

	@GetMapping("/alumnos/editar/{id}")
	public String editar(Model model, @PathVariable int id) {
		return alumnoService.findById(id)
				.map(alumno -> {
					model.addAttribute("alumno", alumno);
					model.addAttribute("grupos", grupoService.findAll());
					return "form-alumno";
				})
				.orElse("redirect:/alumnos");
	}

	@PostMapping("/alumnos/editar/{id}")
	public String submitEditar(@PathVariable int id, @Valid @ModelAttribute("alumno") Alumno alumno, BindingResult br, Model model) {
		if (br.hasErrors()) {
			model.addAttribute("grupos", grupoService.findAll());
			return "form-alumno";
		}
		alumno.setId(id);
		try {
			alumnoService.update(alumno);
		} catch (DataIntegrityViolationException e) {
			br.reject("duplicado", "Ya existe un alumno con ese NIA o email.");
			model.addAttribute("grupos", grupoService.findAll());
			return "form-alumno";
		}
		return "redirect:/alumnos";
	}

	@PostMapping("/alumnos/borrar/{id}")
	public String borrar(@PathVariable int id) {
		alumnoService.delete(id);
		return "redirect:/alumnos";
	}

	private Map<Integer, String> nombresGrupos() {
		return grupoService.findAll().stream()
				.collect(Collectors.toMap(g -> g.getId(), g -> g.getCodigo()));
	}
}
