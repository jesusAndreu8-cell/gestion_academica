package org.iesvdm.gestion.dao;

import java.util.List;
import java.util.Optional;

import org.iesvdm.gestion.dto.AlumnoGrupoDTO;
import org.iesvdm.gestion.modelo.Alumno;

public interface AlumnoDAO {
	List<Alumno> findAll();
	Optional<Alumno> findById(int id);
	void save(Alumno alumno);
	void update(Alumno alumno);
	void delete(int id);
	List<Alumno> findAlumnosByGrupoId(int grupoId);
	List<AlumnoGrupoDTO> findAlumnosConGrupoByTutorId(int profesorId);
}
