package org.iesvdm.gestion.dto;

public record AlumnoGrupoDTO(
		int alumnoId,
		String nia,
		String nombre,
		String apellido1,
		String apellido2,
		String email,
		String grupoCodigo,
		String grupoNombre) {
}
