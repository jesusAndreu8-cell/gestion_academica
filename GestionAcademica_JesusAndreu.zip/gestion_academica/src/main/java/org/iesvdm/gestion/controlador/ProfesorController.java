package org.iesvdm.gestion.controlador;

import java.math.BigDecimal;
import java.util.Optional;

import org.iesvdm.gestion.modelo.Profesor;
import org.iesvdm.gestion.modelo.TutoriaTFG;
import org.iesvdm.gestion.servicios.AlumnoService;
import org.iesvdm.gestion.servicios.ProfesorService;
import org.iesvdm.gestion.servicios.TutoriaTFGService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;

@Controller
public class ProfesorController {

	private final ProfesorService profesorService;
	private final AlumnoService alumnoService;
	private final TutoriaTFGService tutoriaTFGService;

	public ProfesorController(ProfesorService profesorService, AlumnoService alumnoService,
			TutoriaTFGService tutoriaTFGService) {
		this.profesorService = profesorService;
		this.alumnoService = alumnoService;
		this.tutoriaTFGService = tutoriaTFGService;
	}

	@GetMapping("/profesores")
	public String listar(Model model) {
		model.addAttribute("profesores", profesorService.findAll());
		return "profesores";
	}

	@GetMapping("/profesores/{id}")
	public String detalle(Model model, @PathVariable int id) {
		Optional<Profesor> profesorOpt = profesorService.findById(id);
		if (profesorOpt.isEmpty()) return "redirect:/profesores";

		var alumnos = profesorService.alumnosOrdenados(id);
		model.addAttribute("profesor", profesorOpt.get());
		model.addAttribute("grupos", profesorService.gruposDelProfesor(id));
		model.addAttribute("alumnos", alumnos);
		model.addAttribute("resumen", profesorService.resumenPorGrupo(alumnos));
		model.addAttribute("tutorias", tutoriaTFGService.listarPorProfesor(id));
		model.addAttribute("estadisticas", tutoriaTFGService.estadisticas(id));
		model.addAttribute("alumnosDisponibles", alumnoService.findAll());
		return "detalle-profesor";
	}

	/** Asigna un alumno al profesor o actualiza nota y observaciones si ya existe la tutoría. */
	@PostMapping("/profesores/{id}/tutorias")
	public String asignarTutoria(@PathVariable int id,
			@RequestParam int alumnoId,
			@RequestParam(required = false) BigDecimal nota,
			@RequestParam(required = false) String observaciones,
			RedirectAttributes redirectAttributes) {

		if (profesorService.findById(id).isEmpty()) return "redirect:/profesores";

		if (alumnoService.findById(alumnoId).isEmpty()) {
			redirectAttributes.addFlashAttribute("error", "El alumno indicado no existe.");
			return "redirect:/profesores/" + id;
		}
		if (nota != null && (nota.compareTo(BigDecimal.ZERO) < 0 || nota.compareTo(BigDecimal.TEN) > 0)) {
			redirectAttributes.addFlashAttribute("error", "La nota debe estar entre 0 y 10.");
			return "redirect:/profesores/" + id;
		}

		String obs = (observaciones == null || observaciones.isBlank()) ? null : observaciones.trim();
		tutoriaTFGService.asignarOActualizar(new TutoriaTFG(id, alumnoId, nota, obs));
		redirectAttributes.addFlashAttribute("ok", "Tutoría guardada correctamente.");
		return "redirect:/profesores/" + id;
	}

	@GetMapping("/profesores/crear")
	public String crear(Model model) {
		model.addAttribute("profesor", new Profesor());
		return "form-profesor";
	}

	@PostMapping("/profesores/crear")
	public String submitCrear(@Valid @ModelAttribute("profesor") Profesor profesor, BindingResult br) {
		if (br.hasErrors()) {
			return "form-profesor";
		}
		try {
			profesorService.save(profesor);
		} catch (DataIntegrityViolationException e) {
			br.reject("duplicado", "Ya existe un profesor con ese NIF o email.");
			return "form-profesor";
		}
		return "redirect:/profesores";
	}

	@GetMapping("/profesores/editar/{id}")
	public String editar(Model model, @PathVariable int id) {
		return profesorService.findById(id)
				.map(profesor -> {
					model.addAttribute("profesor", profesor);
					return "form-profesor";
				})
				.orElse("redirect:/profesores");
	}

	@PostMapping("/profesores/editar/{id}")
	public String submitEditar(@PathVariable int id, @Valid @ModelAttribute("profesor") Profesor profesor, BindingResult br) {
		if (br.hasErrors()) {
			return "form-profesor";
		}
		profesor.setId(id);
		try {
			profesorService.update(profesor);
		} catch (DataIntegrityViolationException e) {
			br.reject("duplicado", "Ya existe un profesor con ese NIF o email.");
			return "form-profesor";
		}
		return "redirect:/profesores";
	}

	@PostMapping("/profesores/borrar/{id}")
	public String borrar(@PathVariable int id) {
		profesorService.delete(id);
		return "redirect:/profesores";
	}
}
