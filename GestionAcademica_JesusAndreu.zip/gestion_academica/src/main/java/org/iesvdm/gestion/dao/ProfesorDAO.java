package org.iesvdm.gestion.dao;

import java.util.List;
import java.util.Optional;

import org.iesvdm.gestion.modelo.Profesor;

public interface ProfesorDAO {
	List<Profesor> findAll();
	Optional<Profesor> findById(int id);
	void save(Profesor profesor);
	void update(Profesor profesor);
	void delete(int id);
}
