package org.iesvdm.gestion.dao;

import java.math.BigDecimal;
import java.util.List;

import org.iesvdm.gestion.dto.TutoriaDetalleDTO;
import org.iesvdm.gestion.modelo.TutoriaTFG;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class TutoriaTFGDAOImpl implements TutoriaTFGDAO {

	private static final String SELECT_DETALLE = """
			SELECT t.profesor_id,
			       TRIM(CONCAT(p.nombre, ' ', p.apellido1, ' ', COALESCE(p.apellido2, ''))) AS nombre_profesor,
			       t.alumno_id,
			       TRIM(CONCAT(a.nombre, ' ', a.apellido1, ' ', COALESCE(a.apellido2, ''))) AS nombre_alumno,
			       g.codigo AS codigo_grupo,
			       t.nota,
			       t.observaciones
			FROM tutoria_tfg t
			JOIN profesor p ON t.profesor_id = p.id
			JOIN alumno a ON t.alumno_id = a.id
			LEFT JOIN grupo g ON a.grupo_id = g.id
			""";

	private static final RowMapper<TutoriaDetalleDTO> ROW_MAPPER = (rs, rowNum) -> new TutoriaDetalleDTO(
			rs.getInt("profesor_id"),
			rs.getString("nombre_profesor"),
			rs.getInt("alumno_id"),
			rs.getString("nombre_alumno"),
			rs.getString("codigo_grupo"),
			rs.getBigDecimal("nota"),
			rs.getString("observaciones"));

	private final JdbcTemplate jdbcTemplate;

	public TutoriaTFGDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<TutoriaDetalleDTO> findDetalleByProfesorId(int profesorId) {
		return jdbcTemplate.query(SELECT_DETALLE + " WHERE t.profesor_id = ? ORDER BY a.apellido1, a.nombre",
				ROW_MAPPER, profesorId);
	}

	/** Alta o actualización de la tutoría (clave compuesta profesor_id + alumno_id). */
	@Override
	public void save(TutoriaTFG t) {
		BigDecimal nota = t.getNota();
		int rows = jdbcTemplate.update("""
				INSERT INTO tutoria_tfg (profesor_id, alumno_id, nota, observaciones)
				VALUES (?, ?, ?, ?)
				ON DUPLICATE KEY UPDATE nota = VALUES(nota), observaciones = VALUES(observaciones)
				""", t.getProfesorId(), t.getAlumnoId(), nota, t.getObservaciones());
		log.info("Guardadas {} tutorías TFG.", rows);
	}

	@Override
	public void delete(int profesorId, int alumnoId) {
		int rows = jdbcTemplate.update("DELETE FROM tutoria_tfg WHERE profesor_id = ? AND alumno_id = ?",
				profesorId, alumnoId);
		log.info("Eliminadas {} tutorías TFG.", rows);
	}
}
