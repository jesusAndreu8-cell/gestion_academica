package org.iesvdm.gestion.dao;

import java.util.List;
import java.util.Optional;

import org.iesvdm.gestion.modelo.Profesor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class ProfesorDAOImpl implements ProfesorDAO {

	private static final String SELECT = "SELECT id, nif, nombre, apellido1, apellido2, departamento, email FROM profesor";

	private static final RowMapper<Profesor> ROW_MAPPER = (rs, rowNum) -> new Profesor(
			rs.getInt("id"),
			rs.getString("nif"),
			rs.getString("nombre"),
			rs.getString("apellido1"),
			rs.getString("apellido2"),
			rs.getString("departamento"),
			rs.getString("email"));

	private final JdbcTemplate jdbcTemplate;

	public ProfesorDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<Profesor> findAll() {
		List<Profesor> profesores = jdbcTemplate.query(SELECT + " ORDER BY apellido1, nombre", ROW_MAPPER);
		log.info("Devueltos {} profesores.", profesores.size());
		return profesores;
	}

	@Override
	public Optional<Profesor> findById(int id) {
		return jdbcTemplate.query(SELECT + " WHERE id = ?", ROW_MAPPER, id).stream().findFirst();
	}

	@Override
	public void save(Profesor p) {
		int rows = jdbcTemplate.update(
				"INSERT INTO profesor (nif, nombre, apellido1, apellido2, departamento, email) VALUES (?, ?, ?, ?, ?, ?)",
				p.getNif(), p.getNombre(), p.getApellido1(), p.getApellido2(), p.getDepartamento(), p.getEmail());
		log.info("Insertados {} profesores.", rows);
	}

	@Override
	public void update(Profesor p) {
		int rows = jdbcTemplate.update(
				"UPDATE profesor SET nif = ?, nombre = ?, apellido1 = ?, apellido2 = ?, departamento = ?, email = ? WHERE id = ?",
				p.getNif(), p.getNombre(), p.getApellido1(), p.getApellido2(), p.getDepartamento(), p.getEmail(), p.getId());
		log.info("Actualizados {} profesores.", rows);
	}

	@Override
	public void delete(int id) {
		int rows = jdbcTemplate.update("DELETE FROM profesor WHERE id = ?", id);
		log.info("Eliminados {} profesores.", rows);
	}
}
