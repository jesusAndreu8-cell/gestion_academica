package org.iesvdm.gestion.dto;

public record EstadisticasTFGDTO(double notaMedia, double notaMaxima, double notaMinima, long totalEvaluados) {
}
