package org.iesvdm.gestion.dao;

import java.util.List;
import java.util.Optional;

import org.iesvdm.gestion.modelo.Grupo;

public interface GrupoDAO {
	List<Grupo> findAll();
	Optional<Grupo> findById(int id);
	void save(Grupo grupo);
	void update(Grupo grupo);
	void delete(int id);
	List<Grupo> findGruposByTutorId(int profesorId);
}
