package org.iesvdm.gestion.dao;

import java.util.List;

import org.iesvdm.gestion.dto.TutoriaDetalleDTO;
import org.iesvdm.gestion.modelo.TutoriaTFG;

public interface TutoriaTFGDAO {
	List<TutoriaDetalleDTO> findDetalleByProfesorId(int profesorId);
	void save(TutoriaTFG tutoria);
	void delete(int profesorId, int alumnoId);
}
