package org.iesvdm.gestion.dao;

import java.util.List;
import java.util.Optional;

import org.iesvdm.gestion.modelo.Grupo;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class GrupoDAOImpl implements GrupoDAO {

	private static final String SELECT = "SELECT id, codigo, nombre, curso, tutor_id FROM grupo";

	private static final RowMapper<Grupo> ROW_MAPPER = (rs, rowNum) -> new Grupo(
			rs.getInt("id"),
			rs.getString("codigo"),
			rs.getString("nombre"),
			rs.getInt("curso"),
			rs.getObject("tutor_id", Integer.class));

	private final JdbcTemplate jdbcTemplate;

	public GrupoDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<Grupo> findAll() {
		return jdbcTemplate.query(SELECT + " ORDER BY codigo", ROW_MAPPER);
	}

	@Override
	public Optional<Grupo> findById(int id) {
		return jdbcTemplate.query(SELECT + " WHERE id = ?", ROW_MAPPER, id).stream().findFirst();
	}

	@Override
	public void save(Grupo g) {
		int rows = jdbcTemplate.update(
				"INSERT INTO grupo (codigo, nombre, curso, tutor_id) VALUES (?, ?, ?, ?)",
				g.getCodigo(), g.getNombre(), g.getCurso(), g.getTutorId());
		log.info("Insertados {} grupos.", rows);
	}

	@Override
	public void update(Grupo g) {
		int rows = jdbcTemplate.update(
				"UPDATE grupo SET codigo = ?, nombre = ?, curso = ?, tutor_id = ? WHERE id = ?",
				g.getCodigo(), g.getNombre(), g.getCurso(), g.getTutorId(), g.getId());
		log.info("Actualizados {} grupos.", rows);
	}

	@Override
	public void delete(int id) {
		int rows = jdbcTemplate.update("DELETE FROM grupo WHERE id = ?", id);
		log.info("Eliminados {} grupos.", rows);
	}

	@Override
	public List<Grupo> findGruposByTutorId(int profesorId) {
		return jdbcTemplate.query(SELECT + " WHERE tutor_id = ? ORDER BY codigo", ROW_MAPPER, profesorId);
	}
}
