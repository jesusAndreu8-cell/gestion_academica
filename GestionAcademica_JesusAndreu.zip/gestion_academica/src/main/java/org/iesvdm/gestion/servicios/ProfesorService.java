package org.iesvdm.gestion.servicios;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.iesvdm.gestion.dao.AlumnoDAO;
import org.iesvdm.gestion.dao.GrupoDAO;
import org.iesvdm.gestion.dao.ProfesorDAO;
import org.iesvdm.gestion.dto.AlumnoGrupoDTO;
import org.iesvdm.gestion.dto.ResumenGrupoDTO;
import org.iesvdm.gestion.modelo.Grupo;
import org.iesvdm.gestion.modelo.Profesor;
import org.springframework.stereotype.Service;

@Service
public class ProfesorService {

	private final ProfesorDAO profesorDAO;
	private final GrupoDAO grupoDAO;
	private final AlumnoDAO alumnoDAO;

	public ProfesorService(ProfesorDAO profesorDAO, GrupoDAO grupoDAO, AlumnoDAO alumnoDAO) {
		this.profesorDAO = profesorDAO;
		this.grupoDAO = grupoDAO;
		this.alumnoDAO = alumnoDAO;
	}

	public List<Profesor> findAll() {
		return profesorDAO.findAll();
	}

	public Optional<Profesor> findById(int id) {
		return profesorDAO.findById(id);
	}

	public void save(Profesor profesor) {
		profesorDAO.save(profesor);
	}

	public void update(Profesor profesor) {
		profesorDAO.update(profesor);
	}

	public void delete(int id) {
		profesorDAO.delete(id);
	}

	/** Grupos que tutoriza el profesor. */
	public List<Grupo> gruposDelProfesor(int profesorId) {
		return grupoDAO.findGruposByTutorId(profesorId);
	}

	/** Alumnos de los grupos del profesor, ordenados por apellidos y nombre. */
	public List<AlumnoGrupoDTO> alumnosOrdenados(int profesorId) {
		return alumnoDAO.findAlumnosConGrupoByTutorId(profesorId).stream()
				.sorted(Comparator
						.comparing(AlumnoGrupoDTO::apellido1, Comparator.nullsLast(Comparator.<String>naturalOrder()))
						.thenComparing(AlumnoGrupoDTO::apellido2, Comparator.nullsLast(Comparator.<String>naturalOrder()))
						.thenComparing(AlumnoGrupoDTO::nombre))
				.toList();
	}

	/** Número de alumnos por grupo (código de grupo ordenado). */
	public List<ResumenGrupoDTO> resumenPorGrupo(List<AlumnoGrupoDTO> alumnos) {
		return alumnos.stream()
				.filter(a -> a.grupoCodigo() != null)
				.collect(Collectors.groupingBy(AlumnoGrupoDTO::grupoCodigo, TreeMap::new, Collectors.counting()))
				.entrySet().stream()
				.map(e -> new ResumenGrupoDTO(e.getKey(), e.getValue()))
				.toList();
	}
}
