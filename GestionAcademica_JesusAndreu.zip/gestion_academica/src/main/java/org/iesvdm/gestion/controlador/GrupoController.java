package org.iesvdm.gestion.controlador;

import java.util.Map;
import java.util.stream.Collectors;

import org.iesvdm.gestion.modelo.Grupo;
import org.iesvdm.gestion.servicios.GrupoService;
import org.iesvdm.gestion.servicios.ProfesorService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import jakarta.validation.Valid;

@Controller
public class GrupoController {

	private final GrupoService grupoService;
	private final ProfesorService profesorService;

	public GrupoController(GrupoService grupoService, ProfesorService profesorService) {
		this.grupoService = grupoService;
		this.profesorService = profesorService;
	}

	@GetMapping("/grupos")
	public String listar(Model model) {
		model.addAttribute("grupos", grupoService.findAll());
		model.addAttribute("nombresTutores", nombresTutores());
		return "grupos";
	}

	@GetMapping("/grupos/crear")
	public String crear(Model model) {
		model.addAttribute("grupo", new Grupo());
		model.addAttribute("profesores", profesorService.findAll());
		return "form-grupo";
	}

	@PostMapping("/grupos/crear")
	public String submitCrear(@Valid @ModelAttribute("grupo") Grupo grupo, BindingResult br, Model model) {
		if (br.hasErrors()) {
			model.addAttribute("profesores", profesorService.findAll());
			return "form-grupo";
		}
		try {
			grupoService.save(grupo);
		} catch (DataIntegrityViolationException e) {
			br.reject("duplicado", "Ya existe un grupo con ese código.");
			model.addAttribute("profesores", profesorService.findAll());
			return "form-grupo";
		}
		return "redirect:/grupos";
	}

	@GetMapping("/grupos/editar/{id}")
	public String editar(Model model, @PathVariable int id) {
		return grupoService.findById(id)
				.map(grupo -> {
					model.addAttribute("grupo", grupo);
					model.addAttribute("profesores", profesorService.findAll());
					return "form-grupo";
				})
				.orElse("redirect:/grupos");
	}

	@PostMapping("/grupos/editar/{id}")
	public String submitEditar(@PathVariable int id, @Valid @ModelAttribute("grupo") Grupo grupo, BindingResult br, Model model) {
		if (br.hasErrors()) {
			model.addAttribute("profesores", profesorService.findAll());
			return "form-grupo";
		}
		grupo.setId(id);
		try {
			grupoService.update(grupo);
		} catch (DataIntegrityViolationException e) {
			br.reject("duplicado", "Ya existe un grupo con ese código.");
			model.addAttribute("profesores", profesorService.findAll());
			return "form-grupo";
		}
		return "redirect:/grupos";
	}

	@PostMapping("/grupos/borrar/{id}")
	public String borrar(@PathVariable int id) {
		grupoService.delete(id);
		return "redirect:/grupos";
	}

	private Map<Integer, String> nombresTutores() {
		return profesorService.findAll().stream()
				.collect(Collectors.toMap(p -> p.getId(), p -> p.getNombre() + " " + p.getApellido1()));
	}
}
