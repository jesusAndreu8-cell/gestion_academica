package org.iesvdm.gestion.modelo;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Profesor {
	private int id;
	@NotBlank @Size(max = 9) private String nif;
	@NotBlank @Size(max = 100) private String nombre;
	@NotBlank @Size(max = 100) private String apellido1;
	@Size(max = 100) private String apellido2;
	@NotBlank @Size(max = 100) private String departamento;
	@NotBlank @Email @Size(max = 150) private String email;
}
