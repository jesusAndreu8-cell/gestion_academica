package org.iesvdm.gestion.dto;

public record ResumenGrupoDTO(String codigo, long totalAlumnos) {
}
