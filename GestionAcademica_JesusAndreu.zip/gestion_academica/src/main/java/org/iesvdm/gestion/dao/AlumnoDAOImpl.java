package org.iesvdm.gestion.dao;

import java.util.List;
import java.util.Optional;

import org.iesvdm.gestion.dto.AlumnoGrupoDTO;
import org.iesvdm.gestion.modelo.Alumno;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class AlumnoDAOImpl implements AlumnoDAO {

	private static final String SELECT = "SELECT id, nia, nombre, apellido1, apellido2, email, grupo_id FROM alumno";

	private static final RowMapper<Alumno> ROW_MAPPER = (rs, rowNum) -> new Alumno(
			rs.getInt("id"),
			rs.getString("nia"),
			rs.getString("nombre"),
			rs.getString("apellido1"),
			rs.getString("apellido2"),
			rs.getString("email"),
			rs.getObject("grupo_id", Integer.class));

	private final JdbcTemplate jdbcTemplate;

	public AlumnoDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<Alumno> findAll() {
		return jdbcTemplate.query(SELECT + " ORDER BY apellido1, apellido2, nombre", ROW_MAPPER);
	}

	@Override
	public Optional<Alumno> findById(int id) {
		return jdbcTemplate.query(SELECT + " WHERE id = ?", ROW_MAPPER, id).stream().findFirst();
	}

	@Override
	public void save(Alumno a) {
		int rows = jdbcTemplate.update(
				"INSERT INTO alumno (nia, nombre, apellido1, apellido2, email, grupo_id) VALUES (?, ?, ?, ?, ?, ?)",
				a.getNia(), a.getNombre(), a.getApellido1(), a.getApellido2(), a.getEmail(), a.getGrupoId());
		log.info("Insertados {} alumnos.", rows);
	}

	@Override
	public void update(Alumno a) {
		int rows = jdbcTemplate.update(
				"UPDATE alumno SET nia = ?, nombre = ?, apellido1 = ?, apellido2 = ?, email = ?, grupo_id = ? WHERE id = ?",
				a.getNia(), a.getNombre(), a.getApellido1(), a.getApellido2(), a.getEmail(), a.getGrupoId(), a.getId());
		log.info("Actualizados {} alumnos.", rows);
	}

	@Override
	public void delete(int id) {
		int rows = jdbcTemplate.update("DELETE FROM alumno WHERE id = ?", id);
		log.info("Eliminados {} alumnos.", rows);
	}

	@Override
	public List<Alumno> findAlumnosByGrupoId(int grupoId) {
		return jdbcTemplate.query(SELECT + " WHERE grupo_id = ? ORDER BY apellido1, apellido2, nombre", ROW_MAPPER, grupoId);
	}

	private static final RowMapper<AlumnoGrupoDTO> ALUMNO_GRUPO_MAPPER = (rs, rowNum) -> new AlumnoGrupoDTO(
			rs.getInt("alumno_id"),
			rs.getString("nia"),
			rs.getString("nombre"),
			rs.getString("apellido1"),
			rs.getString("apellido2"),
			rs.getString("email"),
			rs.getString("grupo_codigo"),
			rs.getString("grupo_nombre"));

	@Override
	public List<AlumnoGrupoDTO> findAlumnosConGrupoByTutorId(int profesorId) {
		String sql = """
				SELECT a.id AS alumno_id, a.nia, a.nombre, a.apellido1, a.apellido2, a.email,
				       g.codigo AS grupo_codigo, g.nombre AS grupo_nombre
				FROM alumno a
				JOIN grupo g ON a.grupo_id = g.id
				WHERE g.tutor_id = ?
				""";
		return jdbcTemplate.query(sql, ALUMNO_GRUPO_MAPPER, profesorId);
	}
}
