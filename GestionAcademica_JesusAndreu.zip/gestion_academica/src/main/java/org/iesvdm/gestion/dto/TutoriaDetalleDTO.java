package org.iesvdm.gestion.dto;

import java.math.BigDecimal;

public record TutoriaDetalleDTO(
		int profesorId,
		String nombreCompletoProfesor,
		int alumnoId,
		String nombreCompletoAlumno,
		String codigoGrupo,
		BigDecimal nota,
		String observaciones) {
}
