package org.iesvdm.gestion.servicios;

import java.util.List;
import java.util.Optional;

import org.iesvdm.gestion.dao.AlumnoDAO;
import org.iesvdm.gestion.modelo.Alumno;
import org.springframework.stereotype.Service;

@Service
public class AlumnoService {

	private final AlumnoDAO alumnoDAO;

	public AlumnoService(AlumnoDAO alumnoDAO) {
		this.alumnoDAO = alumnoDAO;
	}

	public List<Alumno> findAll() {
		return alumnoDAO.findAll();
	}

	public Optional<Alumno> findById(int id) {
		return alumnoDAO.findById(id);
	}

	public void save(Alumno alumno) {
		alumnoDAO.save(alumno);
	}

	public void update(Alumno alumno) {
		alumnoDAO.update(alumno);
	}

	public void delete(int id) {
		alumnoDAO.delete(id);
	}
}
