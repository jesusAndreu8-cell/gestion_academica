package org.iesvdm.gestion.modelo;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Grupo {
	private int id;
	@NotBlank @Size(max = 20) private String codigo;
	@NotBlank @Size(max = 100) private String nombre;
	@Min(1) private int curso;
	private Integer tutorId;
}
