package org.iesvdm.gestion.servicios;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

import org.iesvdm.gestion.dao.TutoriaTFGDAO;
import org.iesvdm.gestion.dto.EstadisticasTFGDTO;
import org.iesvdm.gestion.dto.TutoriaDetalleDTO;
import org.iesvdm.gestion.modelo.TutoriaTFG;
import org.springframework.stereotype.Service;

@Service
public class TutoriaTFGService {

	private final TutoriaTFGDAO tutoriaTFGDAO;

	public TutoriaTFGService(TutoriaTFGDAO tutoriaTFGDAO) {
		this.tutoriaTFGDAO = tutoriaTFGDAO;
	}

	public List<TutoriaDetalleDTO> listarPorProfesor(int profesorId) {
		return tutoriaTFGDAO.findDetalleByProfesorId(profesorId);
	}

	public void asignarOActualizar(TutoriaTFG tutoria) {
		tutoriaTFGDAO.save(tutoria);
	}

	public void eliminar(int profesorId, int alumnoId) {
		tutoriaTFGDAO.delete(profesorId, alumnoId);
	}

	/** Métricas de los TFG ya calificados (nota != null) del profesor. */
	public EstadisticasTFGDTO estadisticas(int profesorId) {
		List<Double> notas = tutoriaTFGDAO.findDetalleByProfesorId(profesorId).stream()
				.map(TutoriaDetalleDTO::nota)
				.filter(Objects::nonNull)
				.map(BigDecimal::doubleValue)
				.toList();

		if (notas.isEmpty()) {
			return new EstadisticasTFGDTO(0, 0, 0, 0);
		}
		double media = notas.stream().mapToDouble(Double::doubleValue).average().orElse(0);
		double maxima = notas.stream().mapToDouble(Double::doubleValue).max().orElse(0);
		double minima = notas.stream().mapToDouble(Double::doubleValue).min().orElse(0);
		return new EstadisticasTFGDTO(media, maxima, minima, notas.size());
	}
}
